--
-- PostgreSQL database dump
--

-- Dumped from database version 16.6
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: achievement; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.achievement (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    logic text NOT NULL,
    display character varying(1) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.achievement OWNER TO neondb_owner;

--
-- Name: achievement_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.achievement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.achievement_id_seq OWNER TO neondb_owner;

--
-- Name: achievement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.achievement_id_seq OWNED BY public.achievement.id;


--
-- Name: admin; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.admin (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(256)
);


ALTER TABLE public.admin OWNER TO neondb_owner;

--
-- Name: admin_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_id_seq OWNER TO neondb_owner;

--
-- Name: admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.admin_id_seq OWNED BY public.admin.id;


--
-- Name: course; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.course (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.course OWNER TO neondb_owner;

--
-- Name: course_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.course_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.course_id_seq OWNER TO neondb_owner;

--
-- Name: course_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.course_id_seq OWNED BY public.course.id;


--
-- Name: game; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.game (
    id integer NOT NULL,
    game_code character varying(6) NOT NULL,
    date timestamp without time zone NOT NULL,
    course_id integer NOT NULL
);


ALTER TABLE public.game OWNER TO neondb_owner;

--
-- Name: game_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.game_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.game_id_seq OWNER TO neondb_owner;

--
-- Name: game_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.game_id_seq OWNED BY public.game.id;


--
-- Name: hole; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.hole (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    par integer NOT NULL,
    course_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    image_url character varying(255),
    notes text
);


ALTER TABLE public.hole OWNER TO neondb_owner;

--
-- Name: hole_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.hole_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hole_id_seq OWNER TO neondb_owner;

--
-- Name: hole_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.hole_id_seq OWNED BY public.hole.id;


--
-- Name: localisation_string; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.localisation_string (
    id integer NOT NULL,
    code character varying(100) NOT NULL,
    english_text text NOT NULL,
    french_text text,
    german_text text,
    spanish_text text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.localisation_string OWNER TO neondb_owner;

--
-- Name: localisation_string_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.localisation_string_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.localisation_string_id_seq OWNER TO neondb_owner;

--
-- Name: localisation_string_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.localisation_string_id_seq OWNED BY public.localisation_string.id;


--
-- Name: module_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.module_settings (
    id integer NOT NULL,
    enable_food_drink boolean,
    updated_at timestamp without time zone NOT NULL,
    auto_disable_games boolean DEFAULT false
);


ALTER TABLE public.module_settings OWNER TO neondb_owner;

--
-- Name: module_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.module_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.module_settings_id_seq OWNER TO neondb_owner;

--
-- Name: module_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.module_settings_id_seq OWNED BY public.module_settings.id;


--
-- Name: player; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.player (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.player OWNER TO neondb_owner;

--
-- Name: player_game; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.player_game (
    id integer NOT NULL,
    player_id integer NOT NULL,
    game_id integer NOT NULL
);


ALTER TABLE public.player_game OWNER TO neondb_owner;

--
-- Name: player_game_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.player_game_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.player_game_id_seq OWNER TO neondb_owner;

--
-- Name: player_game_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.player_game_id_seq OWNED BY public.player_game.id;


--
-- Name: player_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.player_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.player_id_seq OWNER TO neondb_owner;

--
-- Name: player_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.player_id_seq OWNED BY public.player.id;


--
-- Name: purchase_details; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.purchase_details (
    id integer NOT NULL,
    games_purchased integer,
    purchase_date date,
    invoice_number character varying(50),
    contact_name character varying(100),
    contact_email character varying(120),
    contact_phone character varying(20),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    notification_sent boolean
);


ALTER TABLE public.purchase_details OWNER TO neondb_owner;

--
-- Name: purchase_details_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.purchase_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_details_id_seq OWNER TO neondb_owner;

--
-- Name: purchase_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.purchase_details_id_seq OWNED BY public.purchase_details.id;


--
-- Name: score; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.score (
    id integer NOT NULL,
    player_game_id integer NOT NULL,
    hole_number integer NOT NULL,
    strokes integer NOT NULL
);


ALTER TABLE public.score OWNER TO neondb_owner;

--
-- Name: score_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.score_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.score_id_seq OWNER TO neondb_owner;

--
-- Name: score_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.score_id_seq OWNED BY public.score.id;


--
-- Name: store_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.store_settings (
    id integer NOT NULL,
    language character varying(10) NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.store_settings OWNER TO neondb_owner;

--
-- Name: store_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.store_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.store_settings_id_seq OWNER TO neondb_owner;

--
-- Name: store_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.store_settings_id_seq OWNED BY public.store_settings.id;


--
-- Name: achievement id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.achievement ALTER COLUMN id SET DEFAULT nextval('public.achievement_id_seq'::regclass);


--
-- Name: admin id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin ALTER COLUMN id SET DEFAULT nextval('public.admin_id_seq'::regclass);


--
-- Name: course id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.course ALTER COLUMN id SET DEFAULT nextval('public.course_id_seq'::regclass);


--
-- Name: game id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.game ALTER COLUMN id SET DEFAULT nextval('public.game_id_seq'::regclass);


--
-- Name: hole id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.hole ALTER COLUMN id SET DEFAULT nextval('public.hole_id_seq'::regclass);


--
-- Name: localisation_string id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.localisation_string ALTER COLUMN id SET DEFAULT nextval('public.localisation_string_id_seq'::regclass);


--
-- Name: module_settings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.module_settings ALTER COLUMN id SET DEFAULT nextval('public.module_settings_id_seq'::regclass);


--
-- Name: player id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.player ALTER COLUMN id SET DEFAULT nextval('public.player_id_seq'::regclass);


--
-- Name: player_game id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.player_game ALTER COLUMN id SET DEFAULT nextval('public.player_game_id_seq'::regclass);


--
-- Name: purchase_details id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchase_details ALTER COLUMN id SET DEFAULT nextval('public.purchase_details_id_seq'::regclass);


--
-- Name: score id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.score ALTER COLUMN id SET DEFAULT nextval('public.score_id_seq'::regclass);


--
-- Name: store_settings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.store_settings ALTER COLUMN id SET DEFAULT nextval('public.store_settings_id_seq'::regclass);


--
-- Data for Name: achievement; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.achievement (id, name, logic, display, created_at, updated_at) FROM stdin;
1	Most Birdies Scored	In the game, which player scored the most number of Birdies?  A Birdy is where a player's total putts for a single hole are one below par.  List the player name (or multiple players if more than one player scored the same number of birdies).  Also indicate how many birdies each player scored in the game.	Y	2025-01-20 14:33:09.756256	2025-01-20 14:33:09.75626
\.


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.admin (id, username, email, password_hash) FROM stdin;
1	admin	admin@example.com	scrypt:32768:8:1$bJCjww15BbK2H7RL$d5c091d116becb81ae2a9fe1917a0962f8ecb1bfb0c69c98d38094d28169dbd795613e32abd796328961cb371693f30f9b1e52d68528f497582a5a2c4dfdaee5
\.


--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.course (id, name, created_at, updated_at) FROM stdin;
2	Sea View	2025-01-07 16:43:31.815286	2025-01-07 16:43:31.815289
3	Mountain View	2025-01-08 12:03:55.8992	2025-01-08 12:03:55.899204
1	Forest Gleneagles	2025-01-07 16:43:24.605676	2025-01-13 16:06:13.896029
\.


--
-- Data for Name: game; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.game (id, game_code, date, course_id) FROM stdin;
1	450774	2025-01-07 16:45:31.16554	1
2	860487	2025-01-07 16:50:26.863635	1
3	844151	2025-01-07 16:53:46.772586	2
4	308968	2025-01-07 16:59:39.517663	2
5	426218	2025-01-07 17:02:56.139658	1
6	849493	2025-01-07 17:03:24.122169	1
7	750012	2025-01-07 17:11:46.428845	1
8	139078	2025-01-07 17:27:35.812769	1
9	293894	2025-01-07 17:29:06.839626	2
10	733100	2025-01-07 17:30:41.163045	2
11	463911	2025-01-07 17:47:41.422952	2
12	668231	2025-01-07 18:16:41.773792	1
13	956767	2025-01-08 11:56:24.331019	1
14	842590	2025-01-08 12:06:29.048461	2
15	185747	2025-01-08 12:52:12.052087	3
16	106026	2025-01-08 14:13:36.729954	3
17	818525	2025-01-08 14:20:55.546162	2
18	406325	2025-01-08 14:20:56.397708	2
19	613339	2025-01-08 14:23:19.870003	3
20	453033	2025-01-08 14:26:23.370442	3
21	900605	2025-01-08 14:29:33.222537	1
22	203958	2025-01-08 14:32:29.930918	1
23	346017	2025-01-08 14:51:00.33133	3
24	366447	2025-01-08 16:08:47.220439	1
25	738737	2025-01-08 16:13:10.99108	3
26	892962	2025-01-08 16:14:13.927286	1
27	621735	2025-01-08 16:21:46.808278	1
28	342243	2025-01-08 16:28:39.178819	3
29	298348	2025-01-08 16:33:15.157912	2
30	596630	2025-01-08 16:49:49.367153	3
31	787875	2025-01-08 16:52:16.748708	1
32	769048	2025-01-09 09:42:33.259423	3
33	974069	2025-01-09 10:48:03.209504	1
34	537221	2025-01-09 12:00:04.243913	1
35	873658	2025-01-09 13:10:50.814517	1
36	225868	2025-01-09 13:14:00.261176	2
37	483956	2025-01-09 14:10:51.342011	1
38	170607	2025-01-09 14:15:14.930617	1
39	390611	2025-01-09 14:18:45.39097	1
40	514150	2025-01-09 14:22:35.419334	3
41	461596	2025-01-09 14:30:22.909557	3
42	517948	2025-01-09 14:35:21.714024	1
43	608974	2025-01-09 14:36:25.443182	1
44	414414	2025-01-09 15:09:44.574384	1
45	289483	2025-01-09 15:12:09.762799	3
46	176658	2025-01-09 15:12:58.142987	3
47	862574	2025-01-09 15:13:33.94345	3
48	426161	2025-01-09 15:15:35.122222	3
49	624835	2025-01-09 15:17:02.998998	1
50	910873	2025-01-09 15:18:20.578274	1
51	370053	2025-01-09 15:20:35.346315	1
52	960688	2025-01-09 15:27:27.066878	1
53	371442	2025-01-09 15:31:27.120299	3
54	205866	2025-01-09 15:37:06.431019	1
55	836419	2025-01-09 15:48:33.100314	2
56	778946	2025-01-09 16:08:43.023931	1
57	350660	2025-01-09 16:09:43.082884	1
58	566768	2025-01-09 16:11:56.963915	1
59	112425	2025-01-10 08:09:09.515344	3
61	941631	2025-01-11 10:50:44.597393	3
62	678577	2025-01-13 10:41:28.550351	1
63	531729	2025-01-13 10:43:24.429075	1
64	182050	2025-01-13 10:59:56.00576	1
65	525997	2025-01-13 11:01:08.868902	1
66	156371	2025-01-13 11:03:14.373471	1
67	691964	2025-01-13 11:06:04.227123	1
68	989132	2025-01-13 11:11:59.558216	1
69	384510	2025-01-13 11:15:36.945483	3
70	853201	2025-01-13 11:17:45.11241	1
71	305980	2025-01-13 11:26:33.652967	1
72	514640	2025-01-13 11:28:45.539867	1
73	370348	2025-01-13 11:33:29.410256	2
74	137689	2025-01-13 11:39:49.012947	1
76	853507	2025-01-13 12:07:31.7778	1
77	184460	2025-01-13 12:11:06.023083	1
75	964726	2025-01-13 11:45:07.999007	1
60	692401	2025-01-10 16:52:28.036319	1
78	851315	2025-01-13 12:20:06.470573	1
79	541071	2025-01-13 12:24:12.375936	3
80	396492	2025-01-13 12:42:39.610658	1
81	102725	2025-01-13 12:49:34.040192	1
82	348547	2025-01-13 12:54:03.907414	1
83	953689	2025-01-13 12:59:15.929095	1
84	755262	2025-01-13 12:59:29.863374	1
85	885064	2025-01-13 13:04:12.830432	1
86	712611	2025-01-13 13:46:42.651562	1
87	774405	2025-01-13 13:51:01.117992	1
88	474402	2025-01-13 13:56:10.61616	1
89	723433	2025-01-13 13:57:28.338917	1
90	503551	2025-01-13 14:12:07.493317	1
91	110120	2025-01-13 14:17:23.137206	1
92	309763	2025-01-13 14:21:03.853424	1
93	494217	2025-01-13 14:30:36.71892	1
94	477629	2025-01-13 14:33:39.422177	1
95	521099	2025-01-13 14:36:49.008361	1
96	405096	2025-01-13 14:45:42.633591	1
97	782756	2025-01-13 14:51:52.408256	1
98	185705	2025-01-13 15:00:22.972847	1
99	724934	2025-01-13 15:03:47.736062	1
100	855407	2025-01-13 15:10:04.195039	1
101	538404	2025-01-13 15:13:25.130406	1
102	895924	2025-01-13 15:24:51.38487	1
103	902945	2025-01-13 15:29:04.576867	1
104	206887	2025-01-13 15:36:37.461768	1
105	891900	2025-01-13 15:40:00.373427	1
106	222712	2025-01-13 15:42:14.952926	1
107	521957	2025-01-13 15:46:52.338748	1
108	139715	2025-01-13 15:57:10.537628	1
109	764692	2025-01-13 16:03:55.815165	1
110	529345	2025-01-13 16:07:31.277817	1
111	471499	2025-01-13 16:07:54.176542	1
112	279468	2025-01-13 16:07:56.540471	1
113	214655	2025-01-13 16:09:07.621693	1
114	843851	2025-01-13 16:16:29.652334	1
115	528456	2025-01-13 16:16:33.419178	1
116	428158	2025-01-20 10:06:56.897251	1
117	149072	2025-01-20 10:24:21.517435	1
118	856452	2025-01-20 10:36:04.651369	1
119	718480	2025-01-20 10:41:40.951382	1
120	348745	2025-01-20 10:46:02.572817	1
121	152238	2025-01-20 10:47:58.031045	1
122	713458	2025-01-20 10:53:00.550012	1
123	225672	2025-01-20 10:57:42.067887	1
124	630560	2025-01-20 11:02:12.130654	1
125	515006	2025-01-20 11:13:56.911409	3
126	512615	2025-01-20 13:51:39.212475	1
127	362352	2025-01-20 15:25:09.728377	2
128	143181	2025-01-20 15:45:02.531704	2
129	156721	2025-01-20 19:34:56.357169	1
130	767042	2025-01-21 10:16:42.886918	3
131	669073	2025-01-21 16:19:54.363257	3
\.


--
-- Data for Name: hole; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.hole (id, name, par, course_id, created_at, updated_at, image_url, notes) FROM stdin;
4	Harbour Point	3	2	2025-01-07 16:44:51.437197	2025-01-07 16:44:51.437201	\N	\N
5	Marine Drive	4	2	2025-01-07 16:45:01.348368	2025-01-07 16:45:01.348372	\N	\N
6	Anchors Away	3	2	2025-01-07 16:45:11.157485	2025-01-07 16:45:11.157488	\N	\N
7	Mermaid's Lair	3	2	2025-01-07 16:55:29.072751	2025-01-07 16:55:29.072755	\N	\N
1	Meteor Shower	2	1	2025-01-07 16:43:59.978435	2025-01-13 12:05:48.194534	/static/hole_images/hole_1_20250113_120500.png	Can you get the ball through the windmill!
3	Mountain Climb	3	1	2025-01-07 16:44:26.227299	2025-01-13 12:42:07.898716	/static/hole_images/hole_3_20250113_124139.png	Beat the dinosaur!  Try coming off the back wall for a good 2!
2	Hop Scotch	2	1	2025-01-07 16:44:16.748523	2025-01-13 14:26:47.598346	/static/hole_images/hole_2_20250113_120447.png	Long putt.  Best to hit off the side wall for par 30.
14	Cliffside Canopy	4	3	2025-01-21 10:11:48.359271	2025-01-21 10:14:27.146102	\N	Positioned near a simulated drop-off, this hole creates the sensation of playing right at a mountain’s edge. Gentle breezes from hidden fans enhance the precarious atmosphere. A well-placed deflection off a rocky barrier can save your shot from veering off-course.
8	Eagle's Nest	3	3	2025-01-08 12:04:20.791058	2025-01-21 10:14:38.103187	\N	Inspired by rushing snow, the design focuses on a straight yet speedy lane. Bumpers guide the ball while echoing the roaring slide of an avalanche. The challenge lies in timing your shot so it doesn’t ricochet uncontrollably off the final barrier.
16	Goat’s Path	3	3	2025-01-21 10:12:05.649822	2025-01-21 10:14:50.505869	\N	This hole takes a twisting route, reflecting the sure-footed climb of a mountain goat. Narrow pathways test how well you can handle abrupt changes in direction. Slight elevation shifts require careful planning to avoid overshooting the cup.
9	Hidden Cave	3	3	2025-01-08 12:04:28.982536	2025-01-21 10:15:03.149282	\N	A lofty perch at the start gives a panoramic view of the green below. The ball rolls downhill, gathering speed just like an eagle swooping from its nest. Strategic obstacles mimic rocky ledges, forcing precision on your descent.
12	Summit Slide	4	3	2025-01-21 10:11:29.11678	2025-01-21 10:15:18.941196	\N	A short, enclosed tunnel lit by twinkling “crystals” provides a magical journey. The ball disappears briefly into glowing darkness, emerging into a bright clearing. Accurate speed control ensures you don’t overshoot the nestled target at the tunnel’s exit.
11	The Scree	5	3	2025-01-21 10:10:11.997542	2025-01-21 10:15:29.958233	\N	This hole’s narrow ridge challenges you to keep the ball centered from start to finish. Any misalignment risks plummeting the ball into a trough on either side. A simple yet tense layout encourages calculated strokes rather than brute force.
13	Timberline Trek	3	3	2025-01-21 10:11:38.720583	2025-01-21 10:15:42.573101	\N	A final climb leads you to a small platform that overlooks the rest of the course. A careful putt off the ledge sends your ball directly toward the waiting cup below. It’s a rewarding finish that combines a panoramic view with a straight, satisfying shot.
15	Avalanche Alley	6	3	2025-01-21 10:11:56.986446	2025-01-21 10:16:14.923022	\N	This hole begins with a sharp incline designed to mimic a mountaintop descent. The ball quickly gains momentum, adding an exhilarating rush as it glides downward. Players must carefully adjust their aim at the base to avoid an abrupt obstacle before the cup.
10	Bear Attack	7	3	2025-01-08 12:04:41.07241	2025-01-21 10:25:50.813501	\N	Set among faux evergreens, this hole features winding paths that evoke a high-altitude forest. The ball weaves between tall, rustic barriers, testing your control. A soft, mossy surface provides enough friction to keep shots precise and challenging.
\.


--
-- Data for Name: localisation_string; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.localisation_string (id, code, english_text, french_text, german_text, spanish_text, created_at, updated_at) FROM stdin;
4	HomePageTitleLine3	Track your scores, compare your results and eat, drink & be merry!	Suivez vos scores, comparez vos résultats et mangez, buvez et réjouissez-vous !			2025-01-09 10:42:01.313074	2025-01-09 10:42:01.313077
1	HomePageTitleLine1	Royal Putts Brandon	Le Royale Putts Lille	Ze Royal Putts Hamburg	Le Putt Royale Madrid	2025-01-09 10:26:01.083802	2025-01-09 10:53:08.531849
5	HomePageLeftBoxLine1	Track Scores	Suivez les scores			2025-01-09 11:04:07.014198	2025-01-09 11:21:27.681727
6	HomePageLeftBoxLine2	Record your scores hole by hole as you play.	Enregistrez vos scores trou par trou pendant que vous jouez.			2025-01-09 11:04:46.709452	2025-01-09 11:21:53.492287
7	HomePageMiddleBoxLine1	View Results	Consultez les résultats			2025-01-09 11:05:19.697975	2025-01-09 11:22:18.925419
9	HomePageMiddleBoxLine2	Review your past games and progress over time.	Passez en revue vos parties passées et votre progression au fil du temps.			2025-01-09 11:06:57.648144	2025-01-09 11:22:46.101915
8	HomePageRightBoxLine1	Compare Stats	Comparez les statistiques			2025-01-09 11:06:24.474747	2025-01-09 11:23:12.055181
10	HomePageRightBoxLine2	Get insights into your performance with detailed statistics.	Obtenez un aperçu de vos performances grâce à des statistiques détaillées.			2025-01-09 11:07:31.488323	2025-01-09 11:23:40.283809
3	HomePageTitleLine2	Scores 'n' More!	Scores et plus encore!			2025-01-09 10:35:52.376872	2025-01-09 11:24:16.327301
11	NewGame	New Game	Nouvelle Partie			2025-01-09 11:28:01.054497	2025-01-09 11:28:01.054501
12	FindGame	Find Game	Trouvez Une Partie			2025-01-09 12:05:32.31874	2025-01-09 12:08:08.53397
13	OrderFoodMenu	Order Food & Drink	Commandez des Boissons			2025-01-09 12:13:22.76136	2025-01-09 12:13:22.761365
50	ToolTipInputGameCode	Enter the 6-digit game code.	Entrez le code du jeu à 6 chiffres.			2025-01-20 11:09:13.503389	2025-01-20 11:09:13.503392
14	StartNewGameButton	Start New Game 	Commencez Une Nouvelle Partie			2025-01-09 12:28:43.320326	2025-01-09 12:32:20.593817
15	SelectCourseTitle	Select Course	Sélectionnez Un Parcours			2025-01-09 12:36:41.017957	2025-01-09 12:36:41.017961
16	SelectCourseDropdown	Choose Course	Choisissez Un Parcours			2025-01-09 12:40:46.455896	2025-01-09 12:40:46.4559
17	PlayerNamesTitle	Player Names	Noms des Joueurs			2025-01-09 12:44:41.431513	2025-01-09 12:44:41.431519
18	PlayerNamesToolTip	Enter player names below. You must add at least one player.	Saisissez les noms des joueurs ci-dessous. Vous devez ajouter au moins un joueur.			2025-01-09 12:51:54.749382	2025-01-09 12:51:54.749387
19	PlayerNameDropdown	Enter player name	Entrez le nom du joueur			2025-01-09 12:57:28.368857	2025-01-09 12:57:28.368862
20	AddNewPlayerButton	Add Another Player	Ajoutez Un Autre Joueur			2025-01-09 13:01:53.448179	2025-01-09 13:01:53.448184
21	StartScoringButton	Start Scoring	Commencez à noter les scores			2025-01-09 13:06:18.879709	2025-01-09 13:06:18.879714
22	EnterGameScoresTitle	Enter Game Scores	Entrez les scores de la partie			2025-01-09 14:13:03.129164	2025-01-09 14:13:03.129168
23	GameCodeToolTip	Game Code:	Code de la Partie:			2025-01-09 14:16:30.211916	2025-01-09 14:16:30.211919
24	GameCodeShareTooltip	Share this code with other players to let them find this game.	Partagez ce code avec les autres joueurs pour leur permettre de trouver cette partie.			2025-01-09 14:20:14.57107	2025-01-09 14:20:14.571073
25	ScoreTableScore	Score	Score			2025-01-09 14:23:33.813455	2025-01-09 14:23:33.813457
27	ScoreTablePlayer	Player	Joueur			2025-01-09 14:25:23.182019	2025-01-09 14:25:23.182032
28	ScoreTableStrokes	Strokes	Coups			2025-01-09 14:26:25.92899	2025-01-09 14:26:25.928993
29	UpdatePlayersButton	Update Players and Continue	Mettre à Jour les Joueurs et Continuer			2025-01-09 14:32:38.050917	2025-01-09 14:32:38.050921
30	EditPlayersTitle	Edit Players	Modifier les Joueurs			2025-01-09 14:43:03.384085	2025-01-09 14:43:03.384089
32	GoToHoleText	Go to Hole	Aller au Trou			2025-01-09 14:53:52.417663	2025-01-09 14:53:52.417666
33	FinishGameButton	Finish Game	Terminer la Partie			2025-01-09 14:57:51.620125	2025-01-09 14:57:51.62013
34	CopyButton	Copy Code	Copier le Code			2025-01-09 15:03:04.305049	2025-01-09 15:03:04.305053
35	CopiedButton	Copied!	Code Copié			2025-01-09 15:04:17.393099	2025-01-09 15:04:59.560617
36	WhatsAppButton	Share to WhatsApp	Partager sur WhatsApp			2025-01-09 15:05:52.289209	2025-01-09 15:05:52.289213
37	OrderFoodButton	Order Food and Drink	Commandez à Manger et à Boire			2025-01-09 15:34:06.809062	2025-01-09 15:34:06.809066
39	ResultsMenu	Results	Résultats			2025-01-09 15:41:00.551683	2025-01-09 15:41:00.551686
40	StatsMenu	Stats	Stats			2025-01-09 15:42:05.840082	2025-01-09 15:42:05.840087
38	EditGameMenu	Edit Game	Modifier la Carte de Score			2025-01-09 15:40:22.232997	2025-01-13 11:02:57.323078
31	NextHoleButton	Next Hole	Suivant			2025-01-09 14:47:36.628535	2025-01-13 15:52:58.317151
41	NumberHolesCourse	Holes	Trous			2025-01-20 10:21:01.612889	2025-01-20 10:21:01.612894
42	SelectCourseError	Please select a course before continuing.	Veuillez sélectionner un parcours avant de continuer.			2025-01-20 10:27:22.477187	2025-01-20 10:27:22.477192
43	AddPlayerError	Please add at least one player before continuing.	Veuillez ajouter au moins un joueur avant de continuer. 			2025-01-20 10:32:57.506771	2025-01-20 10:32:57.506775
44	GenericHole	Hole	Trou			2025-01-20 10:43:57.394964	2025-01-20 10:43:57.394967
45	GenericPar	Par	Par			2025-01-20 10:45:35.041899	2025-01-20 10:45:35.041902
46	ScoreTableCumulative	Total Score	Score Total			2025-01-20 10:51:14.609224	2025-01-20 10:51:14.609227
47	ScoreTablePar	Par +/-	Par +/-			2025-01-20 10:55:44.875728	2025-01-20 10:55:44.875733
48	ErrorNotZero	Please enter a score between 1 and 20.	Veuillez saisir un score compris entre 1 et 20.			2025-01-20 10:59:57.912972	2025-01-20 10:59:57.912975
49	TextInputGameCode	Enter Game Code	Entrez le Code du Jeu			2025-01-20 11:05:47.99002	2025-01-20 11:05:47.990023
51	GameResultsTable	Game Results	Résultats de la Partie			2025-01-20 11:32:50.3426	2025-01-20 11:32:50.342605
52	GameResultsTableDate	Date	Date			2025-01-20 11:37:30.340904	2025-01-20 11:37:30.340907
53	GameResultsTableGameCode	Game Code	Code du Jeu			2025-01-20 11:40:44.98606	2025-01-20 11:40:44.986063
54	GameResultsTablePlayers	Players	Joueurs			2025-01-20 11:44:32.884218	2025-01-20 11:44:32.884221
55	GameResultsTablePutts	Total Putts	Putts Total			2025-01-20 11:47:14.186277	2025-01-20 11:47:14.186279
56	GameResultsTableRank	Ranking	Classement			2025-01-20 11:49:09.565203	2025-01-20 11:49:09.565205
57	OutstandingAchievementsTableTitle	Outstanding Achievements	Réalisations Exceptionnelles			2025-01-20 14:00:49.703145	2025-01-20 14:00:49.703148
58	OutstandingAchievementsTableCol1	Achievement	Accomplissement			2025-01-20 14:08:19.096297	2025-01-20 14:08:19.0963
59	OutstandingAchievementsTableCol2	Player	Joueur			2025-01-20 14:10:18.426002	2025-01-20 14:10:18.426005
60	OutstandingAchievementsTableCol3	Details	Détails			2025-01-20 14:11:53.547051	2025-01-20 14:11:53.547054
61	AchievementBirdy	Most Birdies	Max. Birdies			2025-01-20 14:48:48.058519	2025-01-20 14:53:17.122144
64	StatBogeyMasterTitle	The Bogey Master	Maître des Bogeys			2025-01-21 14:40:39.698996	2025-01-21 14:40:39.698999
65	StatBogeyMasterDescription	Most Bogeys played (holes over par).	Le plus grand nombre de bogeys (trous au-dessus du par).			2025-01-21 14:43:33.739683	2025-01-21 14:43:33.739687
66	StatBogeyMasterInfo	holes over par	trous au-dessus du par			2025-01-21 14:46:50.803245	2025-01-21 14:46:50.803249
67	StatACETitle	The ACE!	L’AS!			2025-01-21 14:50:20.826106	2025-01-21 14:50:20.826109
68	StatACEDescription	Most holes in one.	Le joueur ayant réussi le plus de trous en un.			2025-01-21 14:53:38.29395	2025-01-21 14:53:38.293953
69	StatACEInfo	holes in one	trous en un			2025-01-21 14:54:26.692181	2025-01-21 14:54:26.692184
70	StatParBoiledTitle	Par-Boiled!	Par Joke Needed			2025-01-21 15:00:11.222111	2025-01-21 15:00:11.222114
71	StatParBoiledDescription	Most holes putted in Par.	Le plus grand nombre de trous joués en par.			2025-01-21 15:01:13.45073	2025-01-21 15:01:13.450734
72	StatParBoiledInfo	holes in par	trous en par			2025-01-21 15:02:07.843917	2025-01-21 15:02:07.84392
73	StatBirdyTitle	Birdy Song!	Le Chanson Birdy			2025-01-21 15:03:46.860852	2025-01-21 15:03:46.860856
74	StatBirdyDescription	Most holes putted with a Birdy (one under par)	Le plus grand nombre de trous joués en birdie (un coup sous le par).			2025-01-21 15:06:50.251361	2025-01-21 15:06:50.251365
75	StatBirdyInfo	birdies	birdies			2025-01-21 15:07:30.820187	2025-01-21 15:07:30.820191
76	StatEaglesTitle	Eagles Away!	Eagles Away joke			2025-01-21 15:09:00.50643	2025-01-21 15:09:00.506434
77	StatEaglesDescription	Most holes putted with an Eagle (two under par)	Le plus grand nombre de trous joués en eagle (deux coups sous le par)			2025-01-21 15:10:09.665784	2025-01-21 15:10:09.665787
78	StatEaglesInfo	eagles	eagles			2025-01-21 15:11:19.318145	2025-01-21 15:11:19.318149
79	StatAlbertTitle	Uncle Albert	Oncle Albert			2025-01-21 15:14:05.281586	2025-01-21 15:14:05.281589
80	StatAlbertDescription	Most holes putted with an Albatross (three under par)	Le plus grand nombre de trous joués en albatross (trois coups sous le par)			2025-01-21 15:20:29.989408	2025-01-21 15:20:29.98941
81	StatAlbertInfo	albatrosses	albatrosses			2025-01-21 15:20:54.415466	2025-01-21 15:20:54.41547
82	StatCondorTitle	Ah Condor...	Condor Joke			2025-01-21 15:24:56.713221	2025-01-21 15:24:56.713224
83	StatCondorDescription	Most holes putted with a Condor (four under par)	Le plus grand nombre de trous joués en condor (quatre coups sous le par)			2025-01-21 15:26:00.909102	2025-01-21 15:26:00.909105
84	StatCondorInfo	condors	condors			2025-01-21 15:26:16.845396	2025-01-21 15:26:16.845399
85	StatMrBeanTitle	Mr Bean	Mr Bean			2025-01-21 15:29:34.695691	2025-01-21 15:29:34.695695
86	StatMrBeanDescription	Most strokes on a single hole	Le plus grand nombre de coups sur un seul trou			2025-01-21 15:30:21.979822	2025-01-21 15:30:21.979825
87	StatMrBeanInfo	putts on hole	putts sur le trou			2025-01-21 15:31:14.924986	2025-01-21 15:31:14.92499
88	StatUnderParTitle	Under Par	Sub Par Joke			2025-01-21 15:43:10.376721	2025-01-21 15:43:10.376724
89	StatUnderParDescription	Most holes played under par	Le plus grand nombre de trous joués sous le par			2025-01-21 15:44:05.094929	2025-01-21 15:44:05.094933
90	StatUnderParInfo	holes under par	trous sous le par			2025-01-21 15:44:46.143446	2025-01-21 15:44:46.143449
91	StatStreakerTitle	Streaker!	Streaker Joke			2025-01-21 15:48:57.576939	2025-01-21 15:48:57.576942
92	StatStreakerDescription	Under par for the most consecutive holes 	Le plus grand nombre de trous consécutifs sous le par			2025-01-21 15:49:59.280827	2025-01-21 15:49:59.28083
93	StatStreakerInfo	consecutive holes under par: holes	trous consécutifs sous par:  trous			2025-01-21 15:51:34.104754	2025-01-21 15:51:34.104757
94	PlayerStatsTitle	Player Stats - the Highs and Lows!	Statistiques des Joueurs - Les Hauts et Les Bas!			2025-01-21 15:56:49.273421	2025-01-21 15:56:49.273424
95	PlayerStatsCol1	Stats	Stats			2025-01-21 16:02:15.061456	2025-01-21 16:02:15.06146
96	PlayerStatsCol2	Description	Description			2025-01-21 16:03:17.956204	2025-01-21 16:03:17.956207
97	PlayerStatsCol3	Player	Joueur			2025-01-21 16:04:10.952593	2025-01-21 16:04:10.952596
\.


--
-- Data for Name: module_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.module_settings (id, enable_food_drink, updated_at, auto_disable_games) FROM stdin;
1	t	2025-01-09 12:16:38.610957	f
\.


--
-- Data for Name: player; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.player (id, name) FROM stdin;
1	Pete
2	Tom
3	Tad
4	Tod
5	Ted
6	Jill
7	Jen
8	Jack
9	Brad
10	Clive
11	Nelson
12	Bongani
13	Jordan
14	Mariana
15	Bing
16	Nash
17	Helly
18	Skelly
19	Glen
20	Bill
21	Bob
22	Will
23	Sam
24	Jim
25	Jon
26	Fred
27	Freda
28	Tim
29	ghgg
30	dfgsf
31	sdghdf
32	hj
33	col
34	hgsdfg
35	sigh
36	xbfg
37	dgf
38	dg
39	Tit
40	Fff
41	Gill
42	Bingo
43	JK
44	PT
45	Julie
46	Richard
47	Alf
48	hhhgfd
49	duh
50	Reg
51	Maurice
52	Re
53	Sw
54	sdfgsda
55	sedge
56	try
57	dhgfh
58	fhfgdh
59	ggfg
60	ugh
61	vvv
62	sgfdg
63	hdfghjgf
64	dfsgf
65	fgh
66	jhfdghjg
67	bnvmm
68	high
69	dfhfd
70	sgd
71	hug
72	hoc
73	hgjh
74	sfdgh
75	Eric
76	vcx
77	xcm
78	Fg
79	dfgs
80	set
81	opop
82	fdhg
83	hjhj
84	dogs
85	xf
86	dgfg
87	dsfgh
88	sag
89	gfg
90	fgfgff
91	dgyt
92	dfhg
93	fdsa
94	asdf
95	Tommy
96	Teddy
97	can
98	van
99	fhbgh
100	sfhgghg
101	sdfga
102	asdfsd
103	sgf
104	aged
105	cvvxv
106	Bob 2
107	Bob 3
108	gfds
109	dsfg
110	dfhgfh
111	fight
112	dfghg
113	fig
114	sdgf
115	dfgsg
116	might
117	gfhj
118	gjhfvj
119	fgdhfg
120	gfdhh
121	dfgh
122	ytutyr
123	rtyu
124	gdfg
125	sdfg
126	esfr
127	wear
128	ghjfd
129	shgf
130	rty
131	rytyty
132	fsdghf
133	sdhgf
134	gas
135	dfgfdd
136	kjjkjk
137	ghjh
138	hgf
139	Dick
140	King JLee
141	Desmond
142	Me
143	gfdg
144	jhjhjh
145	Awen
146	Annabel
147	Harry
148	Don
149	len
150	ken
151	ing
152	gwsr
153	shghg
154	shrgfrf
155	dtfjh
156	nmcnv
157	hgfh
158	nmnj
159	bmvn
160	Ben
161	Bikl
162	Rob
163	Den
164	Ggggg
165	Anton
166	Bernard
167	Henri
\.


--
-- Data for Name: player_game; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.player_game (id, player_id, game_id) FROM stdin;
1	1	1
2	2	1
3	3	2
4	4	2
5	5	2
6	6	3
7	7	3
8	8	3
9	9	4
10	10	4
11	11	5
12	12	5
13	13	6
14	14	6
15	15	7
16	16	7
17	17	8
18	18	8
19	19	9
20	20	9
21	6	10
22	20	10
23	19	11
24	21	11
25	22	12
26	23	12
27	24	13
28	25	13
29	26	14
30	27	14
31	28	15
32	2	15
33	20	16
34	5	16
35	5	17
36	20	17
37	5	18
38	20	18
39	29	21
40	30	22
41	31	22
42	32	22
43	5	23
44	20	23
45	24	24
46	33	24
47	34	25
48	35	25
49	36	26
50	37	27
51	38	27
52	2	28
53	39	28
54	40	29
55	41	29
56	42	29
57	13	30
58	13	31
59	43	32
60	44	32
61	45	33
62	46	33
63	47	33
64	48	34
65	49	34
66	50	35
67	51	35
68	52	36
69	53	36
70	54	37
71	55	37
72	56	38
73	57	39
74	58	40
75	59	41
76	60	42
77	61	43
78	62	43
79	63	44
80	64	45
81	65	46
82	66	46
83	67	47
84	68	48
85	69	48
86	37	49
87	70	49
88	71	50
89	72	51
90	68	52
91	73	53
92	74	54
93	75	55
94	13	56
95	22	57
96	23	57
97	76	58
98	77	58
99	26	59
100	27	59
101	5	60
102	6	60
103	78	61
104	79	62
105	80	63
106	81	63
107	82	64
108	83	65
109	37	66
110	84	67
111	85	68
112	55	69
113	86	70
114	87	71
115	88	71
116	89	72
117	90	72
118	91	73
119	92	73
120	93	74
121	94	74
122	95	75
123	96	75
124	89	76
125	55	76
126	97	77
127	98	77
128	99	78
129	100	78
130	101	79
131	102	79
132	103	80
133	104	80
134	105	81
135	77	81
136	12	82
137	24	82
138	22	83
139	23	83
140	22	84
141	23	84
142	21	85
143	106	85
144	107	85
145	13	86
146	108	87
147	109	87
148	65	88
149	110	88
150	111	89
151	112	89
152	113	90
153	114	90
154	115	90
155	116	91
156	117	91
157	118	91
158	119	92
159	92	92
160	120	93
161	121	93
162	122	94
163	123	94
164	124	95
165	125	95
166	126	96
167	127	96
168	128	97
169	74	98
170	129	98
171	130	99
172	131	99
173	132	100
174	133	100
175	57	101
176	121	101
177	134	102
178	121	102
179	6	103
180	8	103
181	135	104
182	125	104
183	136	105
184	137	105
185	138	106
186	55	106
187	2	107
188	139	107
189	140	108
190	141	109
191	11	109
192	142	110
193	141	111
194	1	111
195	141	112
196	1	112
198	144	113
199	47	114
200	145	114
201	146	114
202	47	115
203	145	115
204	146	115
205	147	107
206	19	116
208	149	117
209	150	118
210	151	119
211	152	120
212	153	121
213	154	121
214	155	122
215	156	123
216	157	124
217	112	124
218	158	125
219	159	125
220	21	126
222	26	126
223	26	127
224	161	127
225	10	127
226	19	128
227	162	128
228	163	128
229	164	129
230	165	130
231	166	130
232	51	130
233	19	130
234	167	130
235	26	131
236	160	131
237	2	131
\.


--
-- Data for Name: purchase_details; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.purchase_details (id, games_purchased, purchase_date, invoice_number, contact_name, contact_email, contact_phone, created_at, updated_at, notification_sent) FROM stdin;
1	13	2023-09-25	45454	Royal Putts Ltd	richardstanden+royalputts@gmail.com	07760165889	2025-01-08 11:55:32.777949	2025-01-08 16:30:05.753932	t
\.


--
-- Data for Name: score; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.score (id, player_game_id, hole_number, strokes) FROM stdin;
1	1	1	2
2	2	1	1
3	6	1	1
4	7	1	2
5	8	1	2
6	6	2	1
7	7	2	3
8	8	2	3
9	6	3	2
10	7	3	3
11	8	3	4
12	6	4	2
13	7	4	3
14	8	4	3
15	9	1	5
16	10	1	3
17	9	2	2
18	10	2	3
19	9	3	3
20	10	3	4
21	9	4	2
22	10	4	1
23	11	1	3
24	12	1	4
25	11	2	3
26	12	2	2
27	11	3	1
28	12	3	2
29	13	1	3
30	14	1	2
31	13	2	1
32	14	2	2
33	13	3	4
34	14	3	1
35	15	1	2
36	16	1	1
37	15	2	8
38	16	2	2
39	15	3	2
40	16	3	2
41	17	1	2
42	18	1	2
43	17	2	2
44	18	2	3
45	17	3	1
46	18	3	2
47	21	1	2
48	22	1	3
49	21	2	1
50	22	2	2
51	21	3	2
52	22	3	3
53	21	4	6
54	22	4	5
55	25	1	1
56	26	1	2
57	25	2	3
58	26	2	1
59	27	1	1
60	28	1	2
61	27	2	1
62	28	2	3
63	27	3	2
64	28	3	2
65	29	1	1
66	30	1	3
67	29	2	3
68	30	2	4
69	29	3	1
70	30	3	2
71	29	4	2
72	30	4	3
73	31	1	2
74	32	1	6
75	31	2	5
76	32	2	1
77	31	3	6
78	32	3	2
79	33	1	2
80	34	1	2
81	33	2	1
82	34	2	1
83	33	3	1
84	34	3	1
85	37	1	6
86	38	1	5
87	37	2	1
88	38	2	2
89	37	3	2
90	38	3	2
91	37	4	2
92	38	4	2
93	39	1	1
94	40	1	1
95	41	1	2
96	42	1	3
97	40	2	3
98	41	2	3
99	42	2	1
100	40	3	1
101	41	3	3
102	42	3	1
103	43	1	2
104	44	1	2
105	50	1	0
106	51	1	0
107	52	1	5
108	53	1	3
109	52	2	4
110	53	2	1
111	52	3	7
112	53	3	2
113	54	1	2
115	54	2	2
116	55	2	1
117	54	3	5
118	55	3	1
119	54	4	2
120	55	4	1
114	55	1	10
121	57	1	2
122	57	2	3
123	59	1	1
124	60	1	2
125	59	2	3
126	60	2	1
127	59	3	0
128	60	3	0
129	61	1	1
130	62	1	2
131	61	2	2
132	62	2	2
133	61	3	1
134	62	3	2
135	63	1	2
136	66	1	4
137	67	1	2
138	66	2	2
139	67	2	1
140	66	3	3
141	67	3	1
142	75	1	3
143	75	2	3
145	74	1	0
144	77	1	1
146	78	1	0
147	77	2	0
148	78	2	0
149	75	3	1
150	91	1	1
151	91	2	1
152	91	3	1
153	92	1	0
154	93	1	4
155	93	2	3
156	93	3	1
157	93	4	1
158	95	1	1
159	96	1	2
160	97	1	1
161	98	1	2
162	95	2	0
163	96	2	0
164	99	1	2
165	100	1	3
166	99	2	2
167	100	2	2
168	101	1	2
169	102	1	4
170	104	1	2
172	107	1	2
173	107	2	3
174	107	3	7
175	111	1	0
176	111	2	0
177	111	3	0
178	113	1	0
179	113	2	0
181	103	1	2
182	116	1	1
183	117	1	3
184	116	2	2
185	117	2	2
171	105	1	1
186	116	3	1
187	117	3	1
190	118	2	5
320	179	3	2
193	119	4	1
191	119	2	20
321	180	3	2
188	118	1	20
192	118	4	2
194	118	3	1
195	119	3	5
322	181	1	1
189	119	1	20
323	182	1	2
198	120	3	5
199	121	3	5
196	120	1	8
197	121	1	14
200	120	2	1
201	121	2	2
203	123	1	4
204	122	2	1
205	123	2	2
324	183	1	3
206	122	3	5
207	123	3	5
208	122	4	1
209	123	4	2
202	122	1	13
180	106	1	1
210	105	2	0
211	106	2	0
212	124	1	0
213	125	1	0
214	124	2	0
215	125	2	0
216	126	1	0
217	127	1	0
218	126	2	0
219	127	2	0
220	130	1	1
221	131	1	1
222	130	2	1
223	131	2	2
224	130	3	0
225	131	3	0
226	132	1	1
227	133	1	1
228	132	2	1
229	133	2	2
230	132	3	1
231	133	3	3
232	134	1	0
233	135	1	0
234	136	1	3
235	137	1	2
236	136	2	1
237	137	2	2
238	136	3	2
239	137	3	1
240	140	1	1
241	141	1	2
242	140	2	2
243	141	2	5
244	140	3	1
245	141	3	3
246	142	1	5
247	143	1	4
248	144	1	2
249	142	2	4
250	143	2	2
251	144	2	2
252	142	3	3
253	143	3	4
254	144	3	6
255	145	1	2
257	153	1	1
258	154	1	0
260	153	2	0
261	154	2	0
256	152	1	4
259	152	2	6
262	152	3	0
263	153	3	5
264	154	3	0
266	156	1	1
267	157	1	2
265	155	1	3
268	158	1	5
269	159	1	5
270	158	2	5
271	159	2	2
272	160	1	10
273	161	1	5
275	161	2	10
274	160	2	50
276	160	3	1
277	161	3	0
278	162	1	2
279	163	1	2
280	162	2	3
281	163	2	3
282	162	3	12
283	163	3	10
284	164	1	10
285	165	1	10
286	164	2	5
287	165	2	10
289	165	3	5
288	164	3	0
290	166	1	1
291	167	1	3
292	166	2	1
293	167	2	3
294	168	1	5
295	168	2	0
298	169	2	0
299	170	2	0
297	170	1	4
296	169	1	2
300	171	1	1
301	172	1	2
302	171	2	0
303	172	2	0
304	171	3	0
305	172	3	0
307	176	1	1
326	186	1	1
308	175	2	4
309	176	2	4
327	185	2	1
306	175	1	2
311	178	1	2
310	177	1	3
312	177	2	2
313	178	2	3
314	177	3	5
315	178	3	3
316	179	1	1
317	180	1	1
318	179	2	2
319	180	2	3
328	186	2	4
329	185	3	2
330	186	3	4
325	185	1	3
335	187	3	6
336	188	3	2
333	187	2	12
334	188	2	10
339	189	3	3
340	190	1	3
341	191	1	2
342	190	2	1
331	187	1	17
332	188	1	1
343	191	2	5
344	190	3	2
345	191	3	6
346	192	1	2
337	189	1	2
347	192	2	8
338	189	2	20
348	192	3	1
349	195	1	2
350	196	1	2
351	195	2	5
352	196	2	3
353	195	3	1
354	196	3	1
355	198	1	2
358	204	1	1
359	202	2	2
360	203	2	2
361	204	2	3
362	202	3	2
363	203	3	1
364	204	3	4
365	205	1	3
366	205	2	1
357	203	1	2
367	205	3	3
356	202	1	5
368	206	1	1
370	206	2	2
372	206	3	1
374	212	1	1
375	213	1	2
377	214	2	1
376	214	1	3
378	216	1	1
379	217	1	1
380	216	2	2
381	217	2	1
382	218	1	1
383	219	1	2
384	220	1	1
388	220	3	1
392	222	2	1
391	222	1	1
386	220	2	1
393	223	1	1
395	225	1	3
396	223	2	1
398	225	2	3
400	224	3	2
401	225	3	3
402	223	4	1
404	225	4	3
390	222	3	2
394	224	1	1
397	224	2	1
399	223	3	2
403	224	4	1
405	226	1	1
407	228	1	3
408	226	2	1
409	227	2	3
410	228	2	1
411	226	3	1
412	227	3	1
413	228	3	1
414	226	4	1
415	227	4	1
416	228	4	1
406	227	1	2
417	229	1	3
418	229	2	5
419	229	3	1
422	232	1	4
424	234	1	5
429	234	2	6
427	232	2	3
432	232	3	2
434	234	3	4
435	230	4	3
436	231	4	2
437	232	4	1
438	233	4	3
439	234	4	4
440	230	5	3
441	231	5	2
442	232	5	2
443	233	5	1
444	234	5	5
423	233	1	10
428	233	2	8
433	233	3	5
430	230	3	1
421	231	1	1
420	230	1	2
426	231	2	1
425	230	2	2
431	231	3	1
445	230	6	4
446	231	6	2
447	232	6	3
448	233	6	4
449	234	6	3
450	230	7	2
452	232	7	4
453	233	7	3
454	234	7	2
451	231	7	1
455	230	8	2
456	231	8	18
457	232	8	3
458	233	8	2
459	234	8	1
460	230	9	1
461	231	9	5
462	232	9	2
463	233	9	3
464	234	9	2
465	235	1	2
466	236	1	4
467	237	1	6
468	235	2	5
469	236	2	8
470	237	2	2
471	235	3	2
472	236	3	6
473	237	3	2
474	235	4	5
475	236	4	8
476	237	4	1
477	235	5	3
478	236	5	3
479	237	5	5
480	235	6	7
481	236	6	2
482	237	6	1
483	235	7	6
484	236	7	2
485	237	7	1
486	235	8	2
487	236	8	6
488	237	8	8
489	235	9	4
490	236	9	7
491	237	9	9
\.


--
-- Data for Name: store_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.store_settings (id, language, updated_at) FROM stdin;
1	en	2025-01-21 16:10:43.60254
\.


--
-- Name: achievement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.achievement_id_seq', 1, true);


--
-- Name: admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.admin_id_seq', 1, true);


--
-- Name: course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.course_id_seq', 3, true);


--
-- Name: game_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.game_id_seq', 131, true);


--
-- Name: hole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.hole_id_seq', 16, true);


--
-- Name: localisation_string_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.localisation_string_id_seq', 97, true);


--
-- Name: module_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.module_settings_id_seq', 1, true);


--
-- Name: player_game_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.player_game_id_seq', 237, true);


--
-- Name: player_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.player_id_seq', 167, true);


--
-- Name: purchase_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.purchase_details_id_seq', 1, true);


--
-- Name: score_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.score_id_seq', 491, true);


--
-- Name: store_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.store_settings_id_seq', 1, true);


--
-- Name: achievement achievement_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.achievement
    ADD CONSTRAINT achievement_pkey PRIMARY KEY (id);


--
-- Name: admin admin_email_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_email_key UNIQUE (email);


--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (id);


--
-- Name: admin admin_username_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_username_key UNIQUE (username);


--
-- Name: course course_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_name_key UNIQUE (name);


--
-- Name: course course_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_pkey PRIMARY KEY (id);


--
-- Name: game game_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.game
    ADD CONSTRAINT game_pkey PRIMARY KEY (id);


--
-- Name: hole hole_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.hole
    ADD CONSTRAINT hole_pkey PRIMARY KEY (id);


--
-- Name: localisation_string localisation_string_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.localisation_string
    ADD CONSTRAINT localisation_string_code_key UNIQUE (code);


--
-- Name: localisation_string localisation_string_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.localisation_string
    ADD CONSTRAINT localisation_string_pkey PRIMARY KEY (id);


--
-- Name: module_settings module_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.module_settings
    ADD CONSTRAINT module_settings_pkey PRIMARY KEY (id);


--
-- Name: player_game player_game_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.player_game
    ADD CONSTRAINT player_game_pkey PRIMARY KEY (id);


--
-- Name: player player_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_pkey PRIMARY KEY (id);


--
-- Name: purchase_details purchase_details_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchase_details
    ADD CONSTRAINT purchase_details_pkey PRIMARY KEY (id);


--
-- Name: score score_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.score
    ADD CONSTRAINT score_pkey PRIMARY KEY (id);


--
-- Name: store_settings store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.store_settings
    ADD CONSTRAINT store_settings_pkey PRIMARY KEY (id);


--
-- Name: ix_game_game_code; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_game_game_code ON public.game USING btree (game_code);


--
-- Name: game game_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.game
    ADD CONSTRAINT game_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(id);


--
-- Name: hole hole_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.hole
    ADD CONSTRAINT hole_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(id);


--
-- Name: player_game player_game_game_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.player_game
    ADD CONSTRAINT player_game_game_id_fkey FOREIGN KEY (game_id) REFERENCES public.game(id);


--
-- Name: player_game player_game_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.player_game
    ADD CONSTRAINT player_game_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.player(id);


--
-- Name: score score_player_game_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.score
    ADD CONSTRAINT score_player_game_id_fkey FOREIGN KEY (player_game_id) REFERENCES public.player_game(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

